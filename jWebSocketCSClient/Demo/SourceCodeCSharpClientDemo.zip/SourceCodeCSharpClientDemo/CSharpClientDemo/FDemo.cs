﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ClientLibrary.org.jwebsocket.client.token.tbase;
using ClientLibrary.org.jwebsocket.client.csharp.kit;
using ClientLibrary.org.jwebsocket.client.token.api;
using ClientLibrary.org.jwebsocket.client.common;
using CSharpClientDemo.Class;


namespace CSharpClientDemo
{
    public partial class FDemo : Form
    {
        private WebSocketBaseTokenClient mClient;

        public FDemo()
        {
            InitializeComponent();
        }

        private void FDemo_Load(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (rb_true.Checked)
            {
                if (cb_delay.Text.Equals(String.Empty) || cb_timeout.Text.Equals(String.Empty))
                    MessageBox.Show("CSharp Client Demo", "must meet the data", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                {
                    try
                    {
                        mClient = new WebSocketBaseTokenClient(new WebSocketReliabilityOptions(true, Convert.ToInt32(cb_delay.Text), Convert.ToInt32(cb_timeout.Text)));
                        mClient.AddListener(new WebSocketListener(mClient, this));
                        bt_open.Enabled = true;
                        bt_connect.Enabled = false;
                        bt_disconnect.Enabled = true;
                    }
                    catch (Exception lEx)
                    {
                        MessageBox.Show("CSharp Client Demo", "Error while open connection", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else if (rb_false.Checked)
            {
                try
                {
                    mClient = new WebSocketBaseTokenClient();
                    mClient.AddListener(new WebSocketListener(mClient, this));
                    bt_open.Enabled = true;
                    bt_connect.Enabled = false;
                    bt_disconnect.Enabled = true;
                }
                catch (Exception lEx)
                {
                    MessageBox.Show("CSharp Client Demo", "Error while open connection", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Token lToken = TokenFactory.CreateToken(WebSocketMessage.NS_SYSTEM_PLUGIN, WebSocketMessage.ECHO);
                lToken.SetString("data", tb_send.Text);
                mClient.SendTokenText(lToken, new WebSocketResponse(this));
                lb_logs.Items.Add("Sent Token [ type: " + lToken.GetType() + " -- utid: " + lToken.GetInt("utid") + " -- data: " + lToken.GetString("data")+" ]");
            }
            catch (Exception lEx)
            {
                MessageBox.Show("CSharp Client Demo", "Error while send data", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            lb_logs.Items.Clear();
            lb_logs_ping.Items.Clear();
            tb_send.Clear();
        }

        private void bt_disconnect_Click(object sender, EventArgs e)
        {
            mClient.Close();
            mClient = null;
            bt_connect.Enabled = true;
            bt_disconnect.Enabled = false;
            bt_open.Enabled = false;
            bt_close.Enabled = false;
            bt_send.Enabled = false;
            bt_clear.Enabled = false;
        }

        #region Properties

        public ListBox Lb_Logs
        {
            get { return lb_logs; }
            set { lb_logs = value; }
        }

        public ListBox Lb_Logs_ping
        {
            get { return lb_logs_ping; }
            set { Lb_Logs = value; }
        }

        public Button Bt_connect
        {
            get { return bt_connect; }
            set { bt_connect = value; }
        }

        public Button Bt_disconnect
        {
            get { return bt_disconnect; }
            set { bt_disconnect = value; }
        }

        public Button Bt_send
        {
            get { return bt_send; }
            set { bt_send = value; }
        }

        public Button Bt_close
        {
            get { return bt_close; }
            set { bt_close = value; }
        }

        public Button Bt_open
        {
            get { return bt_open; }
            set { bt_open = value; }
        }

        public Button Bt_clear
        {
            get { return bt_clear; }
            set { bt_clear = value; }
        }

        public RadioButton Rb_true
        {
            get { return rb_true; }
            set { rb_true = value; }
        }

        public RadioButton Rb_false
        {
            get { return rb_false; }
            set { rb_false = value; }
        }

        #endregion

        private void rb_true_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_true.Checked)
            {
                cb_delay.Enabled = true;
                cb_timeout.Enabled = true;
            }
        }

        private void rb_false_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_false.Checked)
            {
                cb_delay.Enabled = false;
                cb_timeout.Enabled = false;
            }
        }

        private void FDemo_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (mClient != null)
            {
                if (mClient.IsRunning())
                    mClient.Close();
            }
            Application.Exit();
        }

        private void bt_open_Click(object sender, EventArgs e)
        {
            mClient.Open(tb_url.Text);
            
        }

        private void bt_close_Click(object sender, EventArgs e)
        {
            mClient.Close();
            tb_send.Clear();
            bt_open.Enabled = true;

        }

    }
}
