﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ClientLibrary.org.jwebsocket.client.token.api;
using ClientLibrary.org.jwebsocket.client.token.tbase;
using ClientLibrary.org.jwebsocket.client.csharp.kit;
using ClientLibrary.org.jwebsocket.client.csharp.api;

namespace CSharpClientDemo.Class
{
    public class WebSocketListener:WebSocketClientTokenListener
    {
        private WebSocketBaseTokenClient mClient;
        private FDemo mForm;

        public WebSocketListener(WebSocketBaseTokenClient aClient,FDemo aForm)
        {
            mClient = aClient;
            mForm = aForm;
        }

        public void ProcessOnTokenText(Token aToken)
        {
          
        }

        public void ProcessOnBinaryMessage(WebSocketPacket aDataPacket)
        {
          
        }

        public void ProcessOnClose(WebSocketCloseReason aCloseReason)
        {
            mForm.Lb_Logs_ping.Items.Clear();
            mForm.Lb_Logs.Items.Add("Close Connection");
            mForm.Bt_close.Enabled = false;
            mForm.Bt_send.Enabled = false;
            mForm.Bt_clear.Enabled = false;
        }

        public void ProcessOnError(WebSocketError aError)
        {
            mForm.Lb_Logs.Items.Add("Error: " + aError.Reason);
       
            if (mForm.Rb_true.Checked)
            {
                mForm.Bt_open.Enabled = false;
                mForm.Bt_close.Enabled = false;
            }
            else if(mForm.Rb_false.Checked)
            {
                mForm.Bt_open.Enabled = true;
                mForm.Bt_close.Enabled = false;
            }
        }

        public void ProcessOnFragment(WebSocketPacket aFragment, int aIndex, int aTotal)
        {
          
        }

        public void ProcessOnOpen(WebSocketHeaders aHeader)
        {
            mForm.Lb_Logs.Items.Add("Client Connected to Server");
            mForm.Lb_Logs.Items.Add("JWSSESSIONID = " + aHeader.GetCookies[0].Split('=')[1].Remove(33, 9));
            mForm.Bt_close.Enabled = true;
            mForm.Bt_open.Enabled = false;
            mForm.Bt_send.Enabled = true;
            mForm.Bt_clear.Enabled = true;
            
        }

        public void ProcessOnPing()
        {
            mForm.Lb_Logs_ping.Items.Add("Sending Ping");
        }

        public void ProcessOnPong()
        {
            mForm.Lb_Logs_ping.Items.Add("Receiving Pong");
        }

        public void ProcessOnTextMessage(WebSocketPacket aDataPacket)
        {
           
        }
    }
}
