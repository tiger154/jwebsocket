App.publish('Timer', {
	getTime: function(){
		return new Date().getTime();
	}
});