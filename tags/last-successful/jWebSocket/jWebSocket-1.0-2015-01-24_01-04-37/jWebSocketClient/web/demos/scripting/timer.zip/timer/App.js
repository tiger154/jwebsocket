App.on('appLoaded', function(){
	App.publish('Timer', {
		getTime: function(){
			return new Date().getTime();
		}
	});
});