﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WebSocket.org.jwebsocket.token;
using WebSocket.org.jwebsocket.token.api;
using WebSocket.org.jwebsocket.token.kit;
using WebSocket.org.jwebsocket.common;
using WebSocket.org.jwebsocket.protocol;
using WebSocket.org.jwebsocket.protocol.kit;

namespace Prueba
{

    class Program
    {
        static void Main(string[] args)
        { 
            WebSocketTokenClient lClient = new WebSocketTokenClient();
            lClient.open += Open;
            lClient.close += Close;
            lClient.error += Error;
            lClient.Open("ws://192.168.42.157:8787/jWebSocket/jWebSocket");
        }

        static void Open(WebSocketTokenClient sender, WebSocketHeaders e)
        {
            IToken lToken = TokenFactory.CreateToken(WebSocketMessage.NS_SYSTEM_PLUGIN, WebSocketMessage.ECHO);
            lToken.SetString("data", "Hello team");
         
            sender.SendToken(lToken, Response);            
        }

        static void Close(WebSocketTokenClient sender, WebSocketCloseReason e)
        {
            Console.WriteLine("WebSocket Close Reason : " + e.ToString());
        }

        static void Error(WebSocketTokenClient sender, WebSocketError e)
        {
            Console.WriteLine("WebSocket Error : " + e.Reason);
        }

        static void Response(WebSocketTokenClient sender, TokenResponse e)
        {
            Console.WriteLine("Sent token : " + e.TokenSend.GetString("data"));
            Console.WriteLine("Recived token : " + e.TokenRecive.GetString("data"));

            sender.Close();
        }
    }
}
