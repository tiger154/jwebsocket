﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DemoSendData.Class;
using ClientLibrary.org.jwebsocket.client.token.tbase;
using ClientLibrary.org.jwebsocket.client.token.api;
using ClientLibrary.org.jwebsocket.client.common;


namespace DemoSendData
{
    public partial class FDemo : Form
    {
        private WebSocketBaseTokenClient mClient = null;
        public FDemo()
        {
            InitializeComponent();
        }

        private void bt_open_Click(object sender, EventArgs e)
        {
            mClient = new WebSocketBaseTokenClient();
            mClient.AddListener(new MyListener(mClient, this));
            mClient.Open(tb_url.Text);
        }

        private void bt_close_Click(object sender, EventArgs e)
        {
            mClient.Close();
            mClient = new WebSocketBaseTokenClient();
        }

        #region Send data

        private void bt_string_Click(object sender, EventArgs e)
        {
            Token lToken = TokenFactory.CreateToken(WebSocketMessage.NS_SYSTEM_PLUGIN, "string");
            lToken.SetString("data", "This is string value");
            mClient.SendTokenText(lToken, new MyStringResponse(this));
            lb_show.Items.Add("Sent Token [ type: " + lToken.GetType() + " -- utid: " + lToken.GetInt("utid") + " -- data: " + lToken.GetString("data") + " ]");
        }

        private void bt_int_Click(object sender, EventArgs e)
        {
            Token lToken = TokenFactory.CreateToken(WebSocketMessage.NS_SYSTEM_PLUGIN, "int");
            lToken.SetInt("data", 9999);
            mClient.SendTokenText(lToken, new MyIntegerResponse(this));
            lb_show.Items.Add("Sent Token [ type: " + lToken.GetType() + " -- utid: " + lToken.GetInt("utid") + " -- data: " + lToken.GetInt("data") + " ]");
        }

        private void bt_double_Click(object sender, EventArgs e)
        {
            Token lToken = TokenFactory.CreateToken(WebSocketMessage.NS_SYSTEM_PLUGIN, "double");
            lToken.SetDouble("data", 555.4);
            mClient.SendTokenText(lToken, new MyDoubleResponse(this));
            lb_show.Items.Add("Sent Token [ type: " + lToken.GetType() + " -- utid: " + lToken.GetInt("utid") + " -- data: " + lToken.GetDouble("data") + " ]");
        }

        private void bt_bool_Click(object sender, EventArgs e)
        {
            Token lToken = TokenFactory.CreateToken(WebSocketMessage.NS_SYSTEM_PLUGIN, "bool");
            lToken.SetBool("data", true);
            mClient.SendTokenText(lToken, new MyBooleanResponse(this));
            lb_show.Items.Add("Sent Token [ type: " + lToken.GetType() + " -- utid: " + lToken.GetInt("utid") + " -- data: " + lToken.GetBool("data") + " ]");
        }

        private void bt_list_Click(object sender, EventArgs e)
        {
            string lValues = String.Empty;
            List<object> lList = new List<object>();
            for (int i = 0; i < 5; i++)
            {
                lList.Add(i + 1);
                lValues += i + 1 + " ";
            }
            Token lToken = TokenFactory.CreateToken(WebSocketMessage.NS_SYSTEM_PLUGIN, "list");
            lToken.SetList("data", lList);
            mClient.SendTokenText(lToken, new MyListResponse(this));
            lb_show.Items.Add("Sent Token [ type: " + lToken.GetType() + " -- utid: " + lToken.GetInt("utid") + " -- data: " + lValues + " ]");
            lValues = String.Empty;
        }

        private void bt_dictionary_Click(object sender, EventArgs e)
        {
            Dictionary<string, object> lDictionary = new Dictionary<string, object>();
            lDictionary.Add("C#", 1);
            lDictionary.Add("java", 2);
            lDictionary.Add("C++", 3);
            Token lToken = TokenFactory.CreateToken(WebSocketMessage.NS_SYSTEM_PLUGIN, "dictionary");
            lToken.SetDictionary("data", lDictionary);
            mClient.SendTokenText(lToken, new MyDictionaryResponse(this));

            string lValues = String.Empty;
            foreach (KeyValuePair<string, object> lItem in lDictionary)
            {
                lValues += lItem.Key + ":" + lItem.Value + "  ";
            }
            lb_show.Items.Add("Sent Token [ type: " + lToken.GetType() + " -- utid: " + lToken.GetInt("utid") + " -- data: [ " + lValues + " ] ]");
        }

        private void bt_token_Click(object sender, EventArgs e)
        {
            Token lTokenData = TokenFactory.CreateToken("NS", "Type");
            lTokenData.SetString("data", "my token");

            Token lToken = TokenFactory.CreateToken(WebSocketMessage.NS_SYSTEM_PLUGIN, "token");
            lToken.SetToken("data", lTokenData);
            mClient.SendTokenText(lToken, new MyTokenResponse(this));

            Dictionary<string, object> lDictionary = lTokenData.GetDictionary();
            string lValues = String.Empty;
            foreach (KeyValuePair<string, object> lItem in lDictionary)
            {
                lValues += lItem.Key + ":" + lItem.Value + "  ";
            }
            lb_show.Items.Add("Sent Token [ type: " + lToken.GetType() + " -- utid: " + lToken.GetInt("utid") + " -- data: Token [ " + lValues + "] ]");
        
        }

        #endregion

        #region Properties

        public GroupBox Gb_send
        {
            get { return gb_send; }
            set { gb_send = value; }
        }

        public Button Bt_close
        {
            get { return bt_close; }
            set { bt_close = value; }
        }

        public Button Bt_open
        {
            get { return bt_open; }
            set { bt_open = value; }
        }

        public ListBox Lb_show
        {
            get { return lb_show; }
            set { lb_show = value; }
        }

        #endregion

        private void button1_Click(object sender, EventArgs e)
        {
            lb_show.Items.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (mClient != null)
            {
                if (mClient.IsRunning())
                    mClient.Close();
            }
            Application.Exit();
        }

        private void FDemo_Load(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
        }

        private void FDemo_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (mClient != null)
            {
                if (mClient.IsRunning())
                    mClient.Close();
            }
            Application.ExitThread();
        }

    }
}
