﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClientLibrary.org.jwebsocket.client.token.api;

namespace DemoSendData.Class
{
    public class MyStringResponse : WebSocketResponseTokenListener
    {
        private FDemo mFDemo;

        public MyStringResponse(FDemo aFDemo)
        {
            mFDemo = aFDemo;
        }

        public void OnFailure(Token aToken)
        {
            
        }

        public void OnResponse(Token aToken)
        {
            mFDemo.Lb_show.Items.Add("Received Token [ type: " + aToken.GetType() + " -- utid: " + aToken.GetInt("utid") + " -- data: " + aToken.GetString("data") + " ]");
        }

        public void OnSuccess(Token aToken)
        {
          
        }

        public void OnTimeout(Token aToken)
        {
          
        }
    }
}
