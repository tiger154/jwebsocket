﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClientLibrary.org.jwebsocket.client.token.api;
using ClientLibrary.org.jwebsocket.client.token.tbase;
using ClientLibrary.org.jwebsocket.client.csharp.api;
using ClientLibrary.org.jwebsocket.client.csharp.kit;

namespace DemoSendData.Class
{
    public class MyListener:WebSocketClientTokenListener
    {
        private WebSocketBaseTokenClient mClient;
        private FDemo mFDemo;

        public MyListener(WebSocketBaseTokenClient aClient, FDemo aFDemo)
        {
            mClient = aClient;
            mFDemo = aFDemo;
        }

        public void ProcessOnTokenText(Token aToken)
        {
            //if (aToken.GetType().Equals("list"))
            //{
            //    List<object> lData =  aToken.GetList("data");
            //    mFDemo.Lb_show.Items.Add("list");
            //}
            //else if (aToken.GetType().Equals("dictionary"))
            //{
            //    Dictionary<String, Object> lData = aToken.GetDictionary("data");
            //    mFDemo.Lb_show.Items.Add("dictionary");
            //}
            //else if (aToken.GetType().Equals("string"))
            //{
            //    string lData = aToken.GetString("data");
            //    mFDemo.Lb_show.Items.Add(lData.ToString());
            //}
            //else if (aToken.GetType().Equals("double"))
            //{
            //    double lData = aToken.GetDouble("data");
            //    mFDemo.Lb_show.Items.Add(lData.ToString());
            //}
            //else if (aToken.GetType().Equals("int"))
            //{
            //    int lData = aToken.GetInt("data");
            //    mFDemo.Lb_show.Items.Add(lData.ToString());
            //}
            //else if (aToken.GetType().Equals("bool"))
            //{
            //    bool lData = aToken.GetBool("data");
            //    mFDemo.Lb_show.Items.Add("bool");
            //}
            //else if (aToken.GetType().Equals("token"))
            //{
            //    Token lData = aToken.GetToken("data");
            //    mFDemo.Lb_show.Items.Add(lData.ToString());
            //}
        }

        public void ProcessOnBinaryMessage(WebSocketPacket aDataPacket)
        {
            
        }

        public void ProcessOnClose(WebSocketCloseReason aCloseReason)
        {
            mFDemo.Gb_send.Enabled = false;
            mFDemo.Bt_close.Enabled = false;
            mFDemo.Bt_open.Enabled = true;
            mFDemo.Lb_show.Items.Add("Close Connection");
     
        }

        public void ProcessOnError(WebSocketError aError)
        {
           
        }

        public void ProcessOnFragment(WebSocketPacket aFragment, int aIndex, int aTotal)
        {
          
        }

        public void ProcessOnOpen(WebSocketHeaders aHeader)
        {
            mFDemo.Gb_send.Enabled = true;
            mFDemo.Bt_close.Enabled = true;
            mFDemo.Bt_open.Enabled = false;
            mFDemo.Lb_show.Items.Add("Open Connection");
        }

        public void ProcessOnPing()
        {
           
        }

        public void ProcessOnPong()
        {
           
        }

        public void ProcessOnTextMessage(WebSocketPacket aDataPacket)
        {
          
        }
    }
}
