﻿namespace DemoSendData
{
    partial class FDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_show = new System.Windows.Forms.ListBox();
            this.bt_open = new System.Windows.Forms.Button();
            this.bt_close = new System.Windows.Forms.Button();
            this.gb_connection = new System.Windows.Forms.GroupBox();
            this.bt_string = new System.Windows.Forms.Button();
            this.bt_int = new System.Windows.Forms.Button();
            this.bt_double = new System.Windows.Forms.Button();
            this.bt_bool = new System.Windows.Forms.Button();
            this.bt_list = new System.Windows.Forms.Button();
            this.bt_dictionary = new System.Windows.Forms.Button();
            this.gb_send = new System.Windows.Forms.GroupBox();
            this.bt_token = new System.Windows.Forms.Button();
            this.tb_url = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.gb_connection.SuspendLayout();
            this.gb_send.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_show
            // 
            this.lb_show.Location = new System.Drawing.Point(12, 51);
            this.lb_show.Name = "lb_show";
            this.lb_show.Size = new System.Drawing.Size(478, 342);
            this.lb_show.TabIndex = 0;
            // 
            // bt_open
            // 
            this.bt_open.Location = new System.Drawing.Point(8, 19);
            this.bt_open.Name = "bt_open";
            this.bt_open.Size = new System.Drawing.Size(75, 23);
            this.bt_open.TabIndex = 1;
            this.bt_open.Text = "Open";
            this.bt_open.UseVisualStyleBackColor = true;
            this.bt_open.Click += new System.EventHandler(this.bt_open_Click);
            // 
            // bt_close
            // 
            this.bt_close.Enabled = false;
            this.bt_close.Location = new System.Drawing.Point(8, 49);
            this.bt_close.Name = "bt_close";
            this.bt_close.Size = new System.Drawing.Size(75, 23);
            this.bt_close.TabIndex = 2;
            this.bt_close.Text = "Close";
            this.bt_close.UseVisualStyleBackColor = true;
            this.bt_close.Click += new System.EventHandler(this.bt_close_Click);
            // 
            // gb_connection
            // 
            this.gb_connection.Controls.Add(this.bt_close);
            this.gb_connection.Controls.Add(this.bt_open);
            this.gb_connection.Location = new System.Drawing.Point(502, 12);
            this.gb_connection.Name = "gb_connection";
            this.gb_connection.Size = new System.Drawing.Size(92, 81);
            this.gb_connection.TabIndex = 3;
            this.gb_connection.TabStop = false;
            this.gb_connection.Text = "Connection";
            // 
            // bt_string
            // 
            this.bt_string.Location = new System.Drawing.Point(10, 18);
            this.bt_string.Name = "bt_string";
            this.bt_string.Size = new System.Drawing.Size(75, 23);
            this.bt_string.TabIndex = 4;
            this.bt_string.Text = "String";
            this.bt_string.UseVisualStyleBackColor = true;
            this.bt_string.Click += new System.EventHandler(this.bt_string_Click);
            // 
            // bt_int
            // 
            this.bt_int.Location = new System.Drawing.Point(10, 47);
            this.bt_int.Name = "bt_int";
            this.bt_int.Size = new System.Drawing.Size(75, 23);
            this.bt_int.TabIndex = 5;
            this.bt_int.Text = "Integer";
            this.bt_int.UseVisualStyleBackColor = true;
            this.bt_int.Click += new System.EventHandler(this.bt_int_Click);
            // 
            // bt_double
            // 
            this.bt_double.Location = new System.Drawing.Point(10, 76);
            this.bt_double.Name = "bt_double";
            this.bt_double.Size = new System.Drawing.Size(75, 23);
            this.bt_double.TabIndex = 6;
            this.bt_double.Text = "Double";
            this.bt_double.UseVisualStyleBackColor = true;
            this.bt_double.Click += new System.EventHandler(this.bt_double_Click);
            // 
            // bt_bool
            // 
            this.bt_bool.Location = new System.Drawing.Point(10, 105);
            this.bt_bool.Name = "bt_bool";
            this.bt_bool.Size = new System.Drawing.Size(75, 23);
            this.bt_bool.TabIndex = 7;
            this.bt_bool.Text = "Boolean";
            this.bt_bool.UseVisualStyleBackColor = true;
            this.bt_bool.Click += new System.EventHandler(this.bt_bool_Click);
            // 
            // bt_list
            // 
            this.bt_list.Location = new System.Drawing.Point(10, 134);
            this.bt_list.Name = "bt_list";
            this.bt_list.Size = new System.Drawing.Size(75, 23);
            this.bt_list.TabIndex = 8;
            this.bt_list.Text = "List";
            this.bt_list.UseVisualStyleBackColor = true;
            this.bt_list.Click += new System.EventHandler(this.bt_list_Click);
            // 
            // bt_dictionary
            // 
            this.bt_dictionary.Location = new System.Drawing.Point(10, 163);
            this.bt_dictionary.Name = "bt_dictionary";
            this.bt_dictionary.Size = new System.Drawing.Size(75, 23);
            this.bt_dictionary.TabIndex = 9;
            this.bt_dictionary.Text = "Dictionary";
            this.bt_dictionary.UseVisualStyleBackColor = true;
            this.bt_dictionary.Click += new System.EventHandler(this.bt_dictionary_Click);
            // 
            // gb_send
            // 
            this.gb_send.Controls.Add(this.bt_token);
            this.gb_send.Controls.Add(this.bt_dictionary);
            this.gb_send.Controls.Add(this.bt_list);
            this.gb_send.Controls.Add(this.bt_bool);
            this.gb_send.Controls.Add(this.bt_double);
            this.gb_send.Controls.Add(this.bt_int);
            this.gb_send.Controls.Add(this.bt_string);
            this.gb_send.Enabled = false;
            this.gb_send.Location = new System.Drawing.Point(502, 99);
            this.gb_send.Name = "gb_send";
            this.gb_send.Size = new System.Drawing.Size(93, 222);
            this.gb_send.TabIndex = 10;
            this.gb_send.TabStop = false;
            this.gb_send.Text = "Send";
            // 
            // bt_token
            // 
            this.bt_token.Location = new System.Drawing.Point(10, 192);
            this.bt_token.Name = "bt_token";
            this.bt_token.Size = new System.Drawing.Size(75, 23);
            this.bt_token.TabIndex = 10;
            this.bt_token.Text = "Token";
            this.bt_token.UseVisualStyleBackColor = true;
            this.bt_token.Click += new System.EventHandler(this.bt_token_Click);
            // 
            // tb_url
            // 
            this.tb_url.Location = new System.Drawing.Point(52, 22);
            this.tb_url.Name = "tb_url";
            this.tb_url.Size = new System.Drawing.Size(293, 20);
            this.tb_url.TabIndex = 11;
            this.tb_url.Text = "ws://localhost:8787//jWebSocket//jWebSocket";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "URL :";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(11, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 13;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(11, 43);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 14;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Location = new System.Drawing.Point(502, 327);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(92, 77);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            // 
            // FDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(605, 412);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_url);
            this.Controls.Add(this.gb_send);
            this.Controls.Add(this.gb_connection);
            this.Controls.Add(this.lb_show);
            this.Name = "FDemo";
            this.ShowIcon = false;
            this.Text = "DemoSendData";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FDemo_FormClosed);
            this.Load += new System.EventHandler(this.FDemo_Load);
            this.gb_connection.ResumeLayout(false);
            this.gb_send.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lb_show;
        private System.Windows.Forms.Button bt_open;
        private System.Windows.Forms.Button bt_close;
        private System.Windows.Forms.GroupBox gb_connection;
        private System.Windows.Forms.Button bt_string;
        private System.Windows.Forms.Button bt_int;
        private System.Windows.Forms.Button bt_double;
        private System.Windows.Forms.Button bt_bool;
        private System.Windows.Forms.Button bt_list;
        private System.Windows.Forms.Button bt_dictionary;
        private System.Windows.Forms.GroupBox gb_send;
        private System.Windows.Forms.TextBox tb_url;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_token;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

