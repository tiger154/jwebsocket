﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClientLibrary.org.jwebsocket.client.token.api;

namespace DemoSendData.Class
{
    public class MyDictionaryResponse : WebSocketResponseTokenListener
    {
        private FDemo mFDemo;

        public MyDictionaryResponse(FDemo aFDemo)
        {
            mFDemo = aFDemo;
        }

        public void OnFailure(Token aToken)
        {

        }

        public void OnResponse(Token aToken)
        {
            Dictionary<string, object> lDictionary = aToken.GetDictionary("data");
            string lValues = String.Empty;

            foreach (KeyValuePair<string, object> lItem in lDictionary)
            {
                lValues += lItem.Key + ":" + lItem.Value + "  ";
            }
            mFDemo.Lb_show.Items.Add("Received Token [ type: " + aToken.GetType() + " -- utid: " + aToken.GetInt("utid") + " -- data: [" + lValues + "] ]");
        }

        public void OnSuccess(Token aToken)
        {

        }

        public void OnTimeout(Token aToken)
        {

        }
    }
}
