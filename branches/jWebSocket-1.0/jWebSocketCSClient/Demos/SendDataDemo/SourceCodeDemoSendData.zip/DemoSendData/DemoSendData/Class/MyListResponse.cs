﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClientLibrary.org.jwebsocket.client.token.api;

namespace DemoSendData.Class
{
    public class MyListResponse : WebSocketResponseTokenListener
    {
        private FDemo mFDemo;

        public MyListResponse(FDemo aFDemo)
        {
            mFDemo = aFDemo;
        }

        public void OnFailure(Token aToken)
        {
            
        }

        public void OnResponse(Token aToken)
        {
            List<object> lList =aToken.GetList("data");
            string lValues = String.Empty;
            for (int i = 0; i < lList.Count; i++)
            {
                lValues += lList[i] + " ";
            }
            mFDemo.Lb_show.Items.Add("Received Token [ type: " + aToken.GetType() + " -- utid: " + aToken.GetInt("utid") + " -- data: " + lValues + " ]");
        }

        public void OnSuccess(Token aToken)
        {
          
        }

        public void OnTimeout(Token aToken)
        {
          
        }
    }
}
