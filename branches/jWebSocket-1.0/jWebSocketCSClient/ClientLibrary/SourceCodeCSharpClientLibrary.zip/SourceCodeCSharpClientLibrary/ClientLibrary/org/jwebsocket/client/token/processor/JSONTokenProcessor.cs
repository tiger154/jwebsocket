﻿/*--------------------------------------------------------------------------------
 * jWebSocket - TimeoutOutputStreamNIOWriter
 * Copyright (c) 2011 Alexander Schulze, Innotrade GmbH
 * -------------------------------------------------------------------------------
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation; either version 3 of the License, or (at your
 * option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for
 * more details.
 * You should have received a copy of the GNU Lesser General Public License along
 * with this program; if not, see <http://www.gnu.org/licenses/lgpl.html>.
 * -------------------------------------------------------------------------------
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using JSON;
using log4net;
using ClientLibrary.org.jwebsocket.client.token.api;
using ClientLibrary.org.jwebsocket.client.csharp.api;
using ClientLibrary.org.jwebsocket.client.common;
using ClientLibrary.org.jwebsocket.client.token.tbase;
using ClientLibrary.org.jwebsocket.client.csharp.csbase;

namespace ClientLibrary.org.jwebsocket.client.token.processor
{

    /// <author>Rolando Betancourt Toucet</author>
    /// <lastUpdate>5/20/2012</lastUpdate>
    /// <summary>
    /// 
    /// </summary>
    public class JSONTokenProcessor
    {
        private static readonly ILog mLog = LogManager.GetLogger(typeof(JSONTokenProcessor).Name);

        public static WebSocketPacket TokenToPacket(Token aToken)
        {
            try
            {
                Dictionary<string, object> lDictionary = aToken.GetDictionary();
                JsonObject lJson = new JsonObject();
                foreach (KeyValuePair<string, object> item in lDictionary)
                {
                    lJson.Add(item.Key, ConvertObjectToJsonObject(item.Value));
                }
                return new WebSocketRawPacket(lJson.ToString());
            }
            catch (Exception lEx)
            {
                if (mLog.IsErrorEnabled)
                    mLog.Error(lEx.Source + WebSocketMessage.SEPARATOR + lEx.Message);
                return null;
            }
        }

        public static Token PacketToToken(WebSocketPacket aDataPacket)
        {
            try
            {
                JsonObject json=new JsonObject(aDataPacket.GetString());
                Dictionary<string, object> lDictionary = new Dictionary<string, object>();

                for (int i = 0; i < json.Count; i++)
                    lDictionary.Add(json.Keys.ElementAt(i), json.Values.ElementAt(i));

                return new DictionaryToken(lDictionary);
            }
            catch (Exception lEx)
            {
                if (mLog.IsErrorEnabled)
                    mLog.Error(lEx.Source + WebSocketMessage.SEPARATOR + lEx.Message);
                return null;
            }
        }

        public static JsonObject TokenToJsonObject(Token aToken)
        {
            try
            {
                Dictionary<string, object> lDictionary = aToken.GetDictionary();
                JsonObject lJson = new JsonObject();
                foreach (KeyValuePair<string, object> item in lDictionary)
                {
                    lJson.Add(item.Key, item.Value);
                }
                return lJson;
            }
            catch (Exception lEx)
            {
                if (mLog.IsErrorEnabled)
                    mLog.Error(lEx.Source + WebSocketMessage.SEPARATOR + lEx.Message);
                return null;
            }
        }

        public static JsonObject DictionaryToJsonObject(Dictionary<string, object> aDictionary)
        {
            try
            {
                JsonObject lJson = new JsonObject();
                foreach (KeyValuePair<string, object> item in aDictionary)
                {
                    lJson.Add(item.Key, item.Value);
                }
                return lJson;
            }
            catch (Exception lEx)
            {
                if (mLog.IsErrorEnabled)
                    mLog.Error(lEx.Source + WebSocketMessage.SEPARATOR + lEx.Message);
                return null;
            }
        }

        public static JsonArray ListToJsonArray(List<object> aList)
        {
            try
            {
                JsonArray lJsonArray = new JsonArray();
                foreach (object lItem in aList)
                {
                    lJsonArray.Add(ConvertObjectToJsonObject(lItem));
                }
                return lJsonArray;
            }
            catch (Exception lEx)
            {
                if (mLog.IsErrorEnabled)
                    mLog.Error(lEx.Source + WebSocketMessage.SEPARATOR + lEx.Message);
                return null;
            }
        }

        public static List<object> JSonArrayToList(JsonArray aJsonArray)
        {
            try
            {
                List<object> lList = new List<object>();
                for (int i = 0; i < aJsonArray.Count; i++)
                {
                    lList.Add(ConvertJsonToObject(aJsonArray[i]));
                }
                return lList;
            }
            catch (Exception lEx)
            {
                if (mLog.IsErrorEnabled)
                    mLog.Error(lEx.Source + WebSocketMessage.SEPARATOR + lEx.Message);
                return null;
            }
        }

        private static Object ConvertJsonToObject(object aObject)
        {
            if (aObject is JsonArray)
                return JSonArrayToList((JsonArray)aObject);
            else if (aObject is JsonObject)
                return JSonObjectToDictionary((JsonObject)aObject);
            else
                return aObject;
        }

        public static Token JsonStringToToken(string aJsonString)
        {
            try
            {
                JsonObject json = new JsonObject(aJsonString);
                Dictionary<string, object> lDictionary = new Dictionary<string, object>();

                for (int i = 0; i < json.Count; i++)
                    lDictionary.Add(json.Keys.ElementAt(i), json.Values.ElementAt(i));

                return new DictionaryToken(lDictionary);
            }
            catch (Exception lEx)
            {
                if (mLog.IsErrorEnabled)
                    mLog.Error(lEx.Source + WebSocketMessage.SEPARATOR + lEx.Message);
                return null;
            }
        }

        public static object ConvertObjectToJsonObject(object aObject)
        {
            try
            {
                if (aObject is List<object>)
                    return ListToJsonArray((List<object>)aObject);
                else if (aObject is Token)
                    return TokenToJsonObject((Token)aObject);
                else if (aObject is Dictionary<string, object>)
                    return DictionaryToJsonObject((Dictionary<string, object>)aObject);
                else if (aObject is object[])
                    return ObjectListToJsonArray((object[])aObject);
                else
                    return aObject;
            }
            catch (Exception lEx)
            {
                if (mLog.IsErrorEnabled)
                    mLog.Error(lEx.Source + WebSocketMessage.SEPARATOR + lEx.Message);
                return null;
            }
        }

        public static JsonArray ObjectListToJsonArray(object[] aObjectList)
        {
            try
            {
                JsonArray lArray = new JsonArray();
                for (int i = 0; i < aObjectList.Length; i++)
                {
                    lArray.Add(ConvertObjectToJsonObject(aObjectList[i]));
                }
                return lArray;
            }
            catch (Exception lEx)
            {
                if (mLog.IsErrorEnabled)
                    mLog.Error(lEx.Source + WebSocketMessage.SEPARATOR + lEx.Message);
                return null;
            }
        }

        public static Dictionary<string, object> JSonObjectToDictionary(JsonObject aJSonObject)
        {
            try
            {
                Dictionary<string, object> lDictionary = new Dictionary<string, object>();

                for (int i = 0; i < aJSonObject.Count; i++)
                    lDictionary.Add(aJSonObject.Keys.ElementAt(i), aJSonObject.Values.ElementAt(i));

                return lDictionary;
            }
            catch (Exception lEx)
            {
                if (mLog.IsErrorEnabled)
                    mLog.Error(lEx.Source + WebSocketMessage.SEPARATOR + lEx.Message);
                return null;
            }
        }

    }
}
