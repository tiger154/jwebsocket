﻿/*--------------------------------------------------------------------------------
 * jWebSocket - TimeoutOutputStreamNIOWriter
 * Copyright (c) 2011 Alexander Schulze, Innotrade GmbH
 * -------------------------------------------------------------------------------
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation; either version 3 of the License, or (at your
 * option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for
 * more details.
 * You should have received a copy of the GNU Lesser General Public License along
 * with this program; if not, see <http://www.gnu.org/licenses/lgpl.html>.
 * -------------------------------------------------------------------------------
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClientLibrary.org.jwebsocket.client.csharp.kit;

namespace ClientLibrary.org.jwebsocket.client.csharp.api
{

    /// <author>Rolando Betancourt Toucet</author>
    /// <lastUpdate>3/26/2012</lastUpdate>
    /// <summary>
    /// Interface for the low level WebSocket listeners.
    /// </summary>
    public interface WebSocketClientListener
    {
        /// <summary>
        /// Invoked when a data packet as text message from a client is received.
        /// </summary>
        /// <param name="aDataPacket">Data packet received.</param>
        void ProcessOnTextMessage(WebSocketPacket aDataPacket);

        /// <summary>
        /// Invoked when a data packet as binary message from a client is received.
        /// </summary>
        /// <param name="aDataPacket">Data packet received.</param>
        void ProcessOnBinaryMessage(WebSocketPacket aDataPacket);

        /// <summary>
        /// Invoked when a fragment from client is received.
        /// </summary>
        /// <param name="aFragment">Data packet fragment received.</param>
        /// <param name="aIndex">Index of fragment.</param>
        /// <param name="aTotal">Total size of fragment.</param>
        void ProcessOnFragment(WebSocketPacket aFragment, int aIndex, int aTotal);

        /// <summary>
        /// Invoked when a new client connects to the Client.
        /// </summary>
        /// <param name="aHeader">Header fields from the handshake.</param>
        void ProcessOnOpen(WebSocketHeaders aHeader);

        /// <summary>
        /// Invoked when a client was disconnted to the Client.
        /// </summary>
        /// <param name="aCloseReason">Represent the reason of the disconnect.</param>
        void ProcessOnClose(WebSocketCloseReason aCloseReason);

        /// <summary>
        /// Invoked when any error occurs.
        /// </summary>
        /// <param name="aError">Description of the error.</param>
        void ProcessOnError(WebSocketError aError);

        /// <summary>
        /// Invoked when client sent a ping.
        /// </summary>
        void ProcessOnPing();

        /// <summary>
        /// Invoked when server sent a pong.
        /// </summary>
        void ProcessOnPong();

    }
}
