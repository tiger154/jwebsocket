﻿/*--------------------------------------------------------------------------------
 * jWebSocket - TimeoutOutputStreamNIOWriter
 * Copyright (c) 2011 Alexander Schulze, Innotrade GmbH
 * -------------------------------------------------------------------------------
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation; either version 3 of the License, or (at your
 * option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for
 * more details.
 * You should have received a copy of the GNU Lesser General Public License along
 * with this program; if not, see <http://www.gnu.org/licenses/lgpl.html>.
 * -------------------------------------------------------------------------------
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClientLibrary.org.jwebsocket.client.token.api;
using ClientLibrary.org.jwebsocket.client.token.tbase;
using ClientLibrary.org.jwebsocket.client.csharp.api;
using ClientLibrary.org.jwebsocket.client.csharp.kit;
using ClientLibrary.org.jwebsocket.client.token.processor;
using ClientLibrary.org.jwebsocket.client.common;

namespace ClientLibrary.org.jwebsocket.client.token.kit
{

    /// <author>Rolando Betancourt Toucet</author>
    /// <lastUpdate>3/26/2012</lastUpdate>
    /// <summary>
    /// 
    /// </summary>
    public class WebSocketTokenListener : WebSocketClientTokenListener
    {
        private WebSocketBaseTokenClient mClient;


        public WebSocketTokenListener(WebSocketBaseTokenClient aClient)
        {
            this.mClient = aClient;
        }

        public void ProcessOnTokenText(Token aToken) { }

        public void ProcessOnBinaryMessage(WebSocketPacket aDataPacket) { }

        public void ProcessOnClose(WebSocketCloseReason aCloseReason) { }

        public void ProcessOnError(WebSocketError aError) { }

        public void ProcessOnFragment(WebSocketPacket aFragment, int aIndex, int aTotal) { }

        public void ProcessOnOpen(WebSocketHeaders aHeader) { }

        public void ProcessOnPing() { }

        public void ProcessOnPong() { }

        public void ProcessOnTextMessage(WebSocketPacket aDataPacket)
        {
            Token lToken = mClient.PacketToToken(aDataPacket);
            string lType = lToken.GetType();

            lock (mClient.PendingResponseQueue)
            {
                if (!lType.Equals(WebSocketMessage.WELCOME) && !lType.Equals(WebSocketMessage.GOODBYTE))
                {
                    try
                    {
                        int lUTID = lToken.GetInt(WebSocketMessage.UTID);
                        int lCode = lToken.GetInt(WebSocketMessage.CODE);

                        PendingResponseQueueItem lPRQI = mClient.PendingResponseQueue[lUTID];
                        if (lPRQI != null)
                        {
                            WebSocketResponseTokenListener lWSRTL = lPRQI.Listener;
                            if (lWSRTL != null)
                            {
                                lWSRTL.OnResponse(lToken);
                                if (lCode == 0)
                                    lWSRTL.OnSuccess(lToken);
                                else
                                    lWSRTL.OnFailure(lToken);
                            }
                            mClient.PendingResponseQueue.Remove(lUTID);
                        }
                    }
                    catch (Exception lEx) { }


                }
                foreach (WebSocketClientListener lListener in mClient.GetLsteners())
                {
                    if (lListener is WebSocketClientTokenListener)
                    {
                        (lListener as WebSocketClientTokenListener).ProcessOnTokenText(lToken);
                    }
                }
            }
        }

    }
}
