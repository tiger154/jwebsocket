﻿/*--------------------------------------------------------------------------------
 * jWebSocket - TimeoutOutputStreamNIOWriter
 * Copyright (c) 2011 Alexander Schulze, Innotrade GmbH
 * -------------------------------------------------------------------------------
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation; either version 3 of the License, or (at your
 * option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for
 * more details.
 * You should have received a copy of the GNU Lesser General Public License along
 * with this program; if not, see <http://www.gnu.org/licenses/lgpl.html>.
 * -------------------------------------------------------------------------------
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClientLibrary.org.jwebsocket.client.token.kit;
using ClientLibrary.org.jwebsocket.client.csharp.csbase;
using ClientLibrary.org.jwebsocket.client.csharp.kit;
using ClientLibrary.org.jwebsocket.client.csharp.api;
using ClientLibrary.org.jwebsocket.client.token.api;
using ClientLibrary.org.jwebsocket.client.common;
using ClientLibrary.org.jwebsocket.client.token.processor;


namespace ClientLibrary.org.jwebsocket.client.token.tbase
{

    /// <author>Rolando Betancourt Toucet</author>
    /// <lastUpdate>3/26/2012</lastUpdate>
    /// <summary>
    /// Token based implementation of <c>WebSocketBaseClient</c>.
    /// </summary>
    public class WebSocketBaseTokenClient:WebSocketBaseClient
    {
        private int CURRENT_TOKEN_ID = 0;
        private Dictionary<int, PendingResponseQueueItem> mPendingResponseQueue =
            new Dictionary<int, PendingResponseQueueItem>();

    
        public WebSocketBaseTokenClient() 
        {
            AddTokenClientListener(new WebSocketTokenListener(this));
        }
         
        public WebSocketBaseTokenClient(WebSocketReliabilityOptions aReliabilityOptions)
            : base(aReliabilityOptions) 
        {
            AddTokenClientListener(new WebSocketTokenListener(this));
        }

        public WebSocketPacket TokenToPacket(Token aToken)
        {
            if (mNegotiatedSubProtocol.SubProtocol.Equals(WebSocketConstants.WS_SUBPROT_JSON))
                return JSONTokenProcessor.TokenToPacket(aToken);
            else if (mNegotiatedSubProtocol.Equals(WebSocketConstants.WS_SUBPROT_CSV))
                throw new NotImplementedException(WebSocketMessage.NOT_IMPLEMENTED_YET);
            else if (mNegotiatedSubProtocol.Equals(WebSocketConstants.WS_FORMAT_XML))
                throw new NotImplementedException(WebSocketMessage.NOT_IMPLEMENTED_YET);
            return null;
        }
     
        public void SendTokenText(Token aToken)
        {
            CURRENT_TOKEN_ID++;
            aToken.SetInt(WebSocketConstants.UTID, CURRENT_TOKEN_ID);
            aToken.IsBinary = false;
            SendToken(aToken, -1);
        }

        public void SendTokenText(Token aToken, WebSocketResponseTokenListener aResponseListener)
        {
            CURRENT_TOKEN_ID++;
            aToken.SetInt(WebSocketConstants.UTID, CURRENT_TOKEN_ID);
            PendingResponseQueueItem lPRQI = new PendingResponseQueueItem(aToken, aResponseListener);
            mPendingResponseQueue.Add(CURRENT_TOKEN_ID, lPRQI);
            aToken.IsBinary = false;
            SendToken(aToken, -1);
        }

        private void SendTokenBinary(Token aToken)
        {
            CURRENT_TOKEN_ID++;
            aToken.SetInt(WebSocketConstants.UTID, CURRENT_TOKEN_ID);
            aToken.IsBinary = true;
            SendToken(aToken, -1);
        }

        private void SendTokenBinary(Token aToken, WebSocketResponseTokenListener aResponseListener)
        {
            CURRENT_TOKEN_ID++;
            aToken.SetInt(WebSocketConstants.UTID, CURRENT_TOKEN_ID);
            PendingResponseQueueItem lPRQI = new PendingResponseQueueItem(aToken, aResponseListener);
            mPendingResponseQueue.Add(CURRENT_TOKEN_ID, lPRQI);
            aToken.IsBinary = true;
            SendToken(aToken, -1);
        }

        private void SendTokenFragmented(Token aToken, int aFragmentSize)
        {
            SendToken(aToken, aFragmentSize);
        }

        private void SendToken(Token aToken,int aFragmentSize)
        {
            if (aToken.IsBinary)
            {
                if (!aFragmentSize.Equals(-1))
                    SendBinary(TokenToPacket(aToken).ByteArray, aFragmentSize);
                else
                    SendBinary(TokenToPacket(aToken).ByteArray);
            }
            else
            {
                if (!aFragmentSize.Equals(-1))
                    SendText(TokenToPacket(aToken).GetString(WebSocketTypeEncoding.UTF8), aFragmentSize);
                else
                    base.SendText(TokenToPacket(aToken).GetString(WebSocketTypeEncoding.UTF8));
            }
        }

        public Token PacketToToken(WebSocketPacket aDataPacket)
        {
            return JSONTokenProcessor.PacketToToken(aDataPacket);
        }

        public void AddTokenClientListener(WebSocketClientTokenListener aTokenListener)
        {
            base.AddListener(aTokenListener);
        }

        public void RemoveTokenClientListener(WebSocketClientTokenListener aTokenListener)
        {
            base.RemoveListener(aTokenListener);
        }

        public Dictionary<int, PendingResponseQueueItem> PendingResponseQueue
        {
            get { return mPendingResponseQueue; }
            set { mPendingResponseQueue = value; }
        }

    }
}
