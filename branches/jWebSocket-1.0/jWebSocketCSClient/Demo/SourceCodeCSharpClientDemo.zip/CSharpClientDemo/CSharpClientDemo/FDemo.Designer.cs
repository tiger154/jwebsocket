﻿namespace CSharpClientDemo
{
    partial class FDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bt_disconnect = new System.Windows.Forms.Button();
            this.bt_connect = new System.Windows.Forms.Button();
            this.tb_url = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.bt_clear = new System.Windows.Forms.Button();
            this.bt_send = new System.Windows.Forms.Button();
            this.tb_send = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cb_timeout = new System.Windows.Forms.ComboBox();
            this.cb_delay = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.rb_false = new System.Windows.Forms.RadioButton();
            this.rb_true = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lb_logs = new System.Windows.Forms.ListBox();
            this.lb_logs_ping = new System.Windows.Forms.ListBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bt_disconnect);
            this.groupBox1.Controls.Add(this.bt_connect);
            this.groupBox1.Controls.Add(this.tb_url);
            this.groupBox1.Location = new System.Drawing.Point(13, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(456, 56);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Server URL";
            // 
            // bt_disconnect
            // 
            this.bt_disconnect.Enabled = false;
            this.bt_disconnect.Location = new System.Drawing.Point(368, 19);
            this.bt_disconnect.Name = "bt_disconnect";
            this.bt_disconnect.Size = new System.Drawing.Size(75, 23);
            this.bt_disconnect.TabIndex = 2;
            this.bt_disconnect.Text = "Disconnect";
            this.bt_disconnect.UseVisualStyleBackColor = true;
            this.bt_disconnect.Click += new System.EventHandler(this.bt_disconnect_Click);
            // 
            // bt_connect
            // 
            this.bt_connect.Location = new System.Drawing.Point(287, 19);
            this.bt_connect.Name = "bt_connect";
            this.bt_connect.Size = new System.Drawing.Size(75, 23);
            this.bt_connect.TabIndex = 1;
            this.bt_connect.Text = "Connect";
            this.bt_connect.UseVisualStyleBackColor = true;
            this.bt_connect.Click += new System.EventHandler(this.button1_Click);
            // 
            // tb_url
            // 
            this.tb_url.Location = new System.Drawing.Point(14, 21);
            this.tb_url.Name = "tb_url";
            this.tb_url.Size = new System.Drawing.Size(249, 20);
            this.tb_url.TabIndex = 0;
            this.tb_url.Text = "ws://localhost:8787//jWebSocket//jWebSocket";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.bt_clear);
            this.groupBox2.Controls.Add(this.bt_send);
            this.groupBox2.Controls.Add(this.tb_send);
            this.groupBox2.Location = new System.Drawing.Point(13, 110);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(456, 56);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Data to Send";
            // 
            // bt_clear
            // 
            this.bt_clear.Enabled = false;
            this.bt_clear.Location = new System.Drawing.Point(368, 19);
            this.bt_clear.Name = "bt_clear";
            this.bt_clear.Size = new System.Drawing.Size(75, 23);
            this.bt_clear.TabIndex = 2;
            this.bt_clear.Text = "Clear";
            this.bt_clear.UseVisualStyleBackColor = true;
            this.bt_clear.Click += new System.EventHandler(this.button4_Click);
            // 
            // bt_send
            // 
            this.bt_send.Enabled = false;
            this.bt_send.Location = new System.Drawing.Point(287, 19);
            this.bt_send.Name = "bt_send";
            this.bt_send.Size = new System.Drawing.Size(75, 23);
            this.bt_send.TabIndex = 1;
            this.bt_send.Text = "Send";
            this.bt_send.UseVisualStyleBackColor = true;
            this.bt_send.Click += new System.EventHandler(this.button3_Click);
            // 
            // tb_send
            // 
            this.tb_send.Location = new System.Drawing.Point(14, 21);
            this.tb_send.Name = "tb_send";
            this.tb_send.Size = new System.Drawing.Size(249, 20);
            this.tb_send.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cb_timeout);
            this.groupBox3.Controls.Add(this.cb_delay);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.rb_false);
            this.groupBox3.Controls.Add(this.rb_true);
            this.groupBox3.Location = new System.Drawing.Point(499, 21);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(145, 145);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Reliability Options";
            // 
            // cb_timeout
            // 
            this.cb_timeout.FormattingEnabled = true;
            this.cb_timeout.Items.AddRange(new object[] {
            "1000",
            "2000",
            "3000",
            "4000",
            "5000",
            "6000",
            "7000",
            "8000",
            "9000",
            "10000"});
            this.cb_timeout.Location = new System.Drawing.Point(76, 105);
            this.cb_timeout.Name = "cb_timeout";
            this.cb_timeout.Size = new System.Drawing.Size(53, 21);
            this.cb_timeout.TabIndex = 5;
            this.cb_timeout.Text = "1000";
            // 
            // cb_delay
            // 
            this.cb_delay.DisplayMember = "0";
            this.cb_delay.FormattingEnabled = true;
            this.cb_delay.Items.AddRange(new object[] {
            "1000",
            "2000",
            "3000",
            "4000",
            "5000",
            "6000",
            "7000",
            "8000",
            "9000",
            "10000"});
            this.cb_delay.Location = new System.Drawing.Point(76, 68);
            this.cb_delay.Name = "cb_delay";
            this.cb_delay.Size = new System.Drawing.Size(53, 21);
            this.cb_delay.TabIndex = 4;
            this.cb_delay.Text = "1000";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Timeout";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Delay";
            // 
            // rb_false
            // 
            this.rb_false.AutoSize = true;
            this.rb_false.Location = new System.Drawing.Point(76, 23);
            this.rb_false.Name = "rb_false";
            this.rb_false.Size = new System.Drawing.Size(50, 17);
            this.rb_false.TabIndex = 1;
            this.rb_false.TabStop = true;
            this.rb_false.Text = "False";
            this.rb_false.UseVisualStyleBackColor = true;
            this.rb_false.CheckedChanged += new System.EventHandler(this.rb_false_CheckedChanged);
            // 
            // rb_true
            // 
            this.rb_true.AutoSize = true;
            this.rb_true.Checked = true;
            this.rb_true.Location = new System.Drawing.Point(18, 23);
            this.rb_true.Name = "rb_true";
            this.rb_true.Size = new System.Drawing.Size(47, 17);
            this.rb_true.TabIndex = 0;
            this.rb_true.TabStop = true;
            this.rb_true.Text = "True";
            this.rb_true.UseVisualStyleBackColor = true;
            this.rb_true.CheckedChanged += new System.EventHandler(this.rb_true_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lb_logs);
            this.groupBox4.Location = new System.Drawing.Point(13, 184);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(456, 229);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Client Logs";
            // 
            // lb_logs
            // 
            this.lb_logs.FormattingEnabled = true;
            this.lb_logs.Location = new System.Drawing.Point(11, 25);
            this.lb_logs.Name = "lb_logs";
            this.lb_logs.Size = new System.Drawing.Size(430, 186);
            this.lb_logs.TabIndex = 0;
            // 
            // lb_logs_ping
            // 
            this.lb_logs_ping.FormattingEnabled = true;
            this.lb_logs_ping.Location = new System.Drawing.Point(13, 25);
            this.lb_logs_ping.Name = "lb_logs_ping";
            this.lb_logs_ping.Size = new System.Drawing.Size(123, 186);
            this.lb_logs_ping.TabIndex = 1;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lb_logs_ping);
            this.groupBox5.Location = new System.Drawing.Point(499, 184);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(145, 229);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Ping Logs";
            // 
            // FDemo
            // 
            this.AcceptButton = this.bt_send;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(659, 426);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "FDemo";
            this.ShowIcon = false;
            this.Text = "CSharp Client Demo";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FDemo_FormClosed);
            this.Load += new System.EventHandler(this.FDemo_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button bt_disconnect;
        private System.Windows.Forms.Button bt_connect;
        private System.Windows.Forms.TextBox tb_url;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button bt_clear;
        private System.Windows.Forms.Button bt_send;
        private System.Windows.Forms.TextBox tb_send;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rb_false;
        private System.Windows.Forms.RadioButton rb_true;
        private System.Windows.Forms.ComboBox cb_delay;
        private System.Windows.Forms.ComboBox cb_timeout;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ListBox lb_logs_ping;
        private System.Windows.Forms.ListBox lb_logs;
        private System.Windows.Forms.GroupBox groupBox5;
    }
}