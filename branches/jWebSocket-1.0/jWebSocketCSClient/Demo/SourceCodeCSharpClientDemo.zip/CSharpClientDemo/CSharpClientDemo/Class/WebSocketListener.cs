﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ClientLibrary.org.jwebsocket.client.token.api;
using ClientLibrary.org.jwebsocket.client.token.tbase;
using ClientLibrary.org.jwebsocket.client.csharp.kit;
using ClientLibrary.org.jwebsocket.client.csharp.api;

namespace CSharpClientDemo.Class
{
    public class WebSocketListener:WebSocketClientTokenListener
    {
        private WebSocketBaseTokenClient mClient;
        private FDemo mForm;

        public WebSocketListener(WebSocketBaseTokenClient aClient,FDemo aForm)
        {
            mClient = aClient;
            mForm = aForm;
        }

        public void ProcessOnTokenText(Token aToken)
        {
          
        }

        public void ProcessOnBinaryMessage(WebSocketPacket aDataPacket)
        {
          
        }

        public void ProcessOnClose(WebSocketCloseReason aCloseReason)
        {
            mForm.Bt_disconnect.Enabled = false;
            mForm.Bt_send.Enabled = false;
            mForm.Bt_clear.Enabled = false;
            if (!mForm.Rb_true.Checked)
                mForm.Bt_connect.Enabled = true;
            mForm.Lb_Logs.Items.Clear();
            mForm.Lb_Logs_ping.Items.Clear();
            mForm.Lb_Logs.Items.Add("Client Close Connection");
        }

        public void ProcessOnError(WebSocketError aError)
        {
            mForm.Lb_Logs.Items.Add("Error: " + aError.Reason);
            mForm.Bt_disconnect.Enabled = false;
            mForm.Bt_send.Enabled = false;
            mForm.Bt_clear.Enabled = false;
            if(!mForm.Rb_true.Checked)
                mForm.Bt_connect.Enabled = true;
        }

        public void ProcessOnFragment(WebSocketPacket aFragment, int aIndex, int aTotal)
        {
          
        }

        public void ProcessOnOpen(WebSocketHeaders aHeader)
        {
            mForm.Lb_Logs.Items.Clear();
            mForm.Lb_Logs.Items.Add("Client Connected to Server");
            mForm.Bt_disconnect.Enabled = true;
            mForm.Bt_send.Enabled = true;
            mForm.Bt_clear.Enabled = true;
            mForm.Bt_connect.Enabled = false;
        }

        public void ProcessOnPing()
        {
            mForm.Lb_Logs_ping.Items.Add("Sending Ping");
        }

        public void ProcessOnPong()
        {
            mForm.Lb_Logs_ping.Items.Add("Receiving Pong");
        }

        public void ProcessOnTextMessage(WebSocketPacket aDataPacket)
        {
           
        }
    }
}
