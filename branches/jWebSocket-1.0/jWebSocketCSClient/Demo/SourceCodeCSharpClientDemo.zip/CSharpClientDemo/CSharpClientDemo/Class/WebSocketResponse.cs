﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ClientLibrary.org.jwebsocket.client.token.api;

namespace CSharpClientDemo.Class
{
    public class WebSocketResponse:WebSocketResponseTokenListener
    {
        private FDemo mForm;

        public WebSocketResponse(FDemo aForm)
        {
            mForm = aForm;
        }

        public void OnFailure(Token aToken)
        {
           
        }

        public void OnResponse(Token aToken)
        {
            mForm.Lb_Logs.Items.Add("Received Token [ type: " + aToken.GetType() + " -- utid: " + aToken.GetInt("utid") + " -- data: " + aToken.GetString("data") + " ]");
        }

        public void OnSuccess(Token aToken)
        {
            
        }

        public void OnTimeout(Token aToken)
        {
           
        }
    }
}
